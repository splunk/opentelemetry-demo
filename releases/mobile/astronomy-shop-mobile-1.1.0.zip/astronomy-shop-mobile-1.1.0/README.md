# Astronomy Shop Mobile v1.1.0

Built on: Mon Jan 19 12:21:51 CET 2026

## Contents

### iOS
- `ios/astronomy-shop.ipa` - iOS app for real devices (ARM64)
- Configuration: Release
- SDK: iphoneos26.0

### Android
- `android/astronomy-shop.apk` - Android APK
- Configuration: Release
- Target SDK: Android 34

## Features
- Splunk RUM instrumentation (@splunk/otel-react-native)
- Backend: https://astronomy-shop-us.splunko11y.com
- Full telemetry and observability

## Deployment

### Sauce Labs
Both builds are ready for direct upload to Sauce Labs:
- Upload the .ipa file for iOS device testing
- Upload the .apk file for Android device testing

### Manual Installation

#### iOS
The .ipa file requires proper code signing for installation on physical devices.

#### Android
The .apk can be installed directly:
```bash
adb install android/astronomy-shop.apk
```

## Build Info
- React Native: 0.74.2
- Expo: 51.0.39
- Splunk RUM: 0.3.4
